
INSERT INTO Students (student_id,first_name, last_name, date_of_birth, email, phone_number) 
VALUES (1,'Jad', 'Dox', '1995-08-15', 'john.dox@example.com', '1234567890');
